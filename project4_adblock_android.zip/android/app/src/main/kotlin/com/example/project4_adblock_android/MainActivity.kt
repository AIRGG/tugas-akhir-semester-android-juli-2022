package com.example.project4_adblock_android

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
